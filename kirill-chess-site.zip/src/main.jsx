
import React from 'react';
import ReactDOM from 'react-dom/client';
import KirillChessSite from './KirillChessSite.jsx';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <KirillChessSite />
  </React.StrictMode>
);
